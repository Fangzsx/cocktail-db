package com.fangzsx.retrofit_room.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.fangzsx.retrofit_room.R
import com.fangzsx.retrofit_room.databinding.FragmentHomeBinding
import com.igalata.bubblepicker.adapter.BubblePickerAdapter
import com.igalata.bubblepicker.model.BubbleGradient
import com.igalata.bubblepicker.model.PickerItem


class HomeFragment : Fragment() {
    private lateinit var binding : FragmentHomeBinding



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val titles = resources.getStringArray(R.array.testnames)
        val images = resources.obtainTypedArray(R.array.images)
        val colors = resources.obtainTypedArray(R.array.colors)

        binding.picker.adapter = object : BubblePickerAdapter{
            override val totalCount: Int
                get() = titles.size

            override fun getItem(position: Int): PickerItem {
                return PickerItem().apply{
                    title = titles[position]
                    gradient = BubbleGradient(colors.getColor((position * 2) % 8, 0),
                        colors.getColor((position * 2) % 8 + 1, 0), BubbleGradient.VERTICAL)
                    textColor = ContextCompat.getColor(activity!!, android.R.color.white)
                    backgroundImage = ContextCompat.getDrawable(activity!!, images.getResourceId(position, 0))
                }
            }

        }


    }


}